//
//  ViewModel.swift
//  WalmartiOSAssessment
//
//  Created by Hanh Vo on 5/25/23.
//

import Foundation

class CountryViewModel {
    private var apiService: ApiServiceProtocol
    var countries = [Country]()
   
    init(apiService: ApiServiceProtocol = ApiService()) {
        self.apiService = apiService
    }
    
    func fetchCountriesData(completion: @escaping () -> ()) {
        apiService.fetchCountries(url: url) { [weak self] (result) in
                switch result {
                case .success(let countries):
                    self?.countries = countries
                case .failure(let error):
                    switch error {
                    case .networkError(let netError):
                        print("Failed to fetch countries due to network error: \(netError)")
                    case .dataNotFound:
                        print("Failed to fetch countries: No data found")
                    case .jsonParsingError(let jsonError):
                        print("Failed to decode JSON", jsonError)
                    case .unknownError:
                        print("Failed to fetch countries due to unknown error")
                    case .invalidUrl:
                        print("Invalid Url")
                    }
                }
                completion()
            }
    }
    
        
    func filterCountries(for searchText: String) -> [Country] {
            if !searchText.isEmpty {
                return countries.filter { country in
                    return (country.name?.lowercased().contains(searchText.lowercased()) ?? false) ||
                        (country.capital?.lowercased().contains(searchText.lowercased()) ?? false)
                }
            } else {
                return countries
            }
        }
    
    func numberOfRowsInSection() -> Int {
        return countries.count
    }
    
    func countryAtIndex(index: Int) -> Country {
            return countries[index]
    }
}
