//
//  WalmartiOSAssessmentTests.swift
//  WalmartiOSAssessmentTests
//
//  Created by Hanh Vo on 5/25/23.
//

import XCTest
@testable import WalmartiOSAssessment

final class WalmartiOSAssessmentTests: XCTestCase {
    var apiService: MockApiService!
    var viewModel: CountryViewModel!
    
    override func setUpWithError() throws {
        apiService = MockApiService()
        viewModel = CountryViewModel(apiService: apiService)
        viewModel.countries = [
            Country(name: "Brazil", region: "Americas", code: "BR", capital: "Brasília"),
            Country(name: "Korea", region: "Asia", code: "KR", capital: "Seoul"),
            Country(name: "France", region: "Europe", code: "FR", capital: "Paris")
        ]
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        viewModel = nil
        apiService = nil
        super.tearDown()
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }
    
    func testFetchCountriesSuccess() {
        
        let country = Country(name: "Korea", region: "Southeast Asia", code: "KRN", capital: "Seoul")
        apiService.countries = [country]

        
        let expectation = XCTestExpectation(description: "Fetch countries successfully")
        viewModel.fetchCountriesData {
            expectation.fulfill()
        }

        
        wait(for: [expectation], timeout: 1)
        XCTAssertEqual(viewModel.numberOfRowsInSection(), 1)
        let fetchedCountry = viewModel.countryAtIndex(index: 0)
        XCTAssertEqual(fetchedCountry.name, "Korea")
        XCTAssertEqual(fetchedCountry.capital, "Seoul")
        XCTAssertEqual(fetchedCountry.region, "Southeast Asia")
        XCTAssertEqual(fetchedCountry.code, "KRN")
    }
    
    func testFetchCountriesFailure() {
       
        apiService.error = .dataNotFound

        
        let expectation = XCTestExpectation(description: "Fetch countries failure")
        viewModel.fetchCountriesData {
            expectation.fulfill()
        }
        
        wait(for: [expectation], timeout: 1)
        XCTAssertEqual(viewModel.numberOfRowsInSection(), 0)
    }
    
    func testFilterCountriesByName() {
        let searchText = "korea"
        let filteredCountries = viewModel.filterCountries(for: searchText)
        XCTAssertEqual(filteredCountries.count, 1)
        XCTAssertEqual(filteredCountries.first?.name, "Korea")
        }
    
    func testFilterCountriesByCapital() {
        let searchText = "brasília"
        let filteredCountries = viewModel.filterCountries(for: searchText)
        XCTAssertEqual(filteredCountries.count, 1)
        XCTAssertEqual(filteredCountries.first?.capital, "Brasília")
        }

    func testFilterCountriesEmptySearchText() {
        let searchText = ""
        let filteredCountries = viewModel.filterCountries(for: searchText)
        XCTAssertEqual(filteredCountries.count, viewModel.countries.count)
    }


    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        // Any test you write for XCTest can be annotated as throws and async.
        // Mark your test throws to produce an unexpected failure when your test encounters an uncaught error.
        // Mark your test async to allow awaiting for asynchronous code to complete. Check the results with assertions afterwards.
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
