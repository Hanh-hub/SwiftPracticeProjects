//
//  ApiServiceMock.swift
//  WalmartiOSAssessment
//
//  Created by Hanh Vo on 5/25/23.
//

import Foundation



class MockApiService: ApiServiceProtocol {
    var countries: [Country]? 
    var error: ApiError?

    func fetchCountries(url: String, completion: @escaping (Result<[Country], ApiError>) -> ()) {
        if let error = error {
            completion(.failure(error))
        } else {
            completion(.success(countries ?? []))
        }
    }
}
