//
//  ApiService.swift
//  WalmartiOSAssessment
//
//  Created by Hanh Vo on 5/25/23.
//

import Foundation

enum ApiError: Error {
    case invalidUrl
    case networkError(Error)
    case dataNotFound
    case jsonParsingError(Error)
    case unknownError
}

protocol ApiServiceProtocol {
    func fetchCountries(url: String, completion: @escaping (Result<[Country], ApiError>) -> ())
}

class ApiService: ApiServiceProtocol {
    func fetchCountries(url: String, completion: @escaping (Result<[Country], ApiError>) -> ()) {
        guard let urlRequest = URL(string: url) else {
            completion(.failure(.invalidUrl))
            return
        }
        URLSession.shared.dataTask(with: urlRequest) { data, response, error in
            if let error = error {
                completion(.failure(.networkError(error)))
                return
            }
            guard let data = data else {
                completion(.failure(.dataNotFound))
                return
            }
            do {
                let countries = try JSONDecoder().decode([Country].self, from: data)
                completion(.success(countries))
            } catch let jsonError {
                completion(.failure(.jsonParsingError(jsonError)))
            }
        }.resume()
    }
    
  
    
    
   
    
    
    
}
