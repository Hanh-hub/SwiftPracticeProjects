//
//  MockApiURLSession.swift
//  WalmartiOSAssessment
//
//  Created by Hanh Vo on 5/25/23.
//

import Foundation

class MockURLSessionDataTask: URLSessionDataTask {
    private let closure: () -> Void
    
    init(closure: @escaping () -> Void) {
        self.closure = closure
    }
    override func resume() {
           closure()
    }
    
    
}
