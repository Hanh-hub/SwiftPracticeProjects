//
//  ViewController.swift
//  WalmartiOSAssessment
//
//  Created by Hanh Vo on 5/25/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate {
    private var viewModel = CountryViewModel()
    @IBOutlet weak var tableView: UITableView!
    var filteredCountries = [Country]()
    let searchController = UISearchController(searchResultsController: nil)
    
    var refreshControl: UIRefreshControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUpTable()
        setUpSearchController()
        fetchData()
        
        refreshControl = UIRefreshControl()
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(refresh(_:)), for: .valueChanged)
        tableView.addSubview(refreshControl)
    }
    
    @objc func refresh(_ sender: AnyObject){
        viewModel.fetchCountriesData { success in
            if success {
                DispatchQueue.main.async {
                    self.filteredCountries = self.viewModel.countries
                    self.tableView.reloadData()
                    self.refreshControl.endRefreshing()
                }
            }
        }
    }

    
    private func setUpTable(){
        tableView.delegate = self
        tableView.dataSource = self
        tableView.rowHeight = UITableView.automaticDimension
        //tableView.estimatedRowHeight = 400
    }
    
    private func setUpSearchController(){
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "Search Countries"
        navigationItem.searchController = searchController
        definesPresentationContext = true
    }
    
    func fetchData(){
        viewModel.fetchCountriesData { success in
            if success {
                DispatchQueue.main.async {
                    self.filteredCountries = self.viewModel.countries
                    self.tableView.reloadData()
                }
            } else {
                DispatchQueue.main.async {
                    self.showAlert(title: "Error", message: "Error getting data")
                }
            }
        }
    }
    
    
    func showAlert(title: String, message: String){
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let actionRetry = UIAlertAction(title: "retry", style: .default){_ in
            self.fetchData()
        }
        let actionDismiss = UIAlertAction(title: "dismiss", style: .cancel)
        
        alertController.addAction(actionRetry)
        alertController.addAction(actionDismiss)
        present(alertController, animated: true)
    }
}


extension ViewController: UISearchResultsUpdating {
    func updateSearchResults(for searchController: UISearchController) {
        if let searchText = searchController.searchBar.text {
            self.filteredCountries = viewModel.filterCountries(for: searchText)
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredCountries.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "CountryCell", for: indexPath) as? CountryCell else {
            fatalError("Unable to dequeue CountryCell")
        }
        let country = filteredCountries[indexPath.row]
        cell.setCountry(country: country)
        return cell
    }
}




