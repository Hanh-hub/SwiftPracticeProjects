//
//  ItemDataManger.swift
//  LuluLemon
//
//  Created by Hanh Vo on 5/11/23.
//

import Foundation
import CoreData

class ItemDataManager{
    var viewContext: NSManagedObjectContext
    private var container = NSPersistentContainer(name: "GarmentTypeModel")
    
    init(){
        container.loadPersistentStores{description, error in
            if let error = error as? NSError {
                fatalError("error loading data \(error) \(error.userInfo)")
            }
        }
        self.viewContext = container.viewContext
    }
    
    static let shared = ItemDataManager()
    
    func addItem(name: String) {
           let newItem = Item(context: viewContext)
           newItem.name = name
           newItem.timestamp = Date()

           do {
               try viewContext.save()
           } catch {
               print("Error adding item: \(error)")
           }
       }
    
    
    func fetchItems(sortedBy: ItemSort) -> [Item] {
           let request: NSFetchRequest<Item> = Item.fetchRequest()
           switch sortedBy {
           case .alphabetical:
               request.sortDescriptors = [NSSortDescriptor(keyPath: \Item.name, ascending: true)]
           case .time:
               request.sortDescriptors = [NSSortDescriptor(keyPath: \Item.timestamp, ascending: true)]
           }

           do {
               let items = try viewContext.fetch(request)
               return items
           } catch {
               print("Error fetching items: \(error)")
               return []
           }
       }
    
    func saveChange(){
        do {
            try viewContext.save()
        } catch let error{
            print("error saving  \(error)")
        }
       
    }
    
    func updateItem(item: Item, newName: String) {
            item.name = newName
       
            do {
                try viewContext.save()
            } catch {
                print("Error updating item: \(error)")
            }
        }
    
    enum ItemSort {
        case alphabetical
        case time
    }
}
