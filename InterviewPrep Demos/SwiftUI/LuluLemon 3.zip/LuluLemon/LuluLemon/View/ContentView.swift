//
//  ContentView.swift
//  LuluLemon
//
//  Created by Hanh Vo on 5/11/23.
//

import SwiftUI

struct ContentView: View {
    @State private var selectedView = 0
    @State private var showAddEditView: Bool = false
    @Environment(\.managedObjectContext) private var viewContext
    @StateObject private var viewModel = ItemViewModel()

    var body: some View {
        
        NavigationView{
            VStack{
                Picker(selection: $selectedView, label: Text("hello")){
                    Text("Alpha").tag(0)
                    Text("Time").tag(1)
                }
                .pickerStyle(.segmented)
                .padding()
                Spacer()
                
                if selectedView == 0 {
                    AlphaView(viewModel: viewModel, sortedBy: .alphabetical)
                } else {
                    AlphaView(viewModel: viewModel, sortedBy: .time)
                }
            }
            .toolbar{
                ToolbarItem(placement: .navigationBarTrailing){
                    NavigationLink(destination: AddEditItemView(viewModel: viewModel, itemName: "")){
                        Image(systemName: "plus.circle")
                    }
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
            ContentView()
    }
}
