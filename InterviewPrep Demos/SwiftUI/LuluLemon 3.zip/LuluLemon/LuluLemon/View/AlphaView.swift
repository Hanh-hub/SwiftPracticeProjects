//
//  AlphaView.swift
//  LuluLemon
//
//  Created by Hanh Vo on 5/11/23.
//

import SwiftUI

struct AlphaView: View {
    @ObservedObject var viewModel: ItemViewModel
    @State private var selectedItem: Item? = nil
    @State private var showAddEditView = false
    
    var sortedBy: ItemDataManager.ItemSort
    

    var body: some View {
        VStack {
            List(viewModel.items){item in
                NavigationLink(destination: AddEditItemView(viewModel: viewModel, item: item, itemName: item.name!)){
                    Text(item.name ?? "unknown")
                }
            }
            .onAppear{
                viewModel.fetchItems(sortedBy: sortedBy)
            }
        }
    }
}

struct AlphaView_Previews: PreviewProvider {
    static var previews: some View {
        AlphaView(viewModel: ItemViewModel(), sortedBy: .alphabetical)
    }
}
