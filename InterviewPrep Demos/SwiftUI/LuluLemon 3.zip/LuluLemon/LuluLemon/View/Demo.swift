//
//  Demo.swift
//  LuluLemon
//
//  Created by Hanh Vo on 5/11/23.
//

import SwiftUI

struct Demo: View {
    @State private var text = "apple"

    var body: some View {
        VStack {
            TextField("Placeholder", text: $text)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            // Other views...
        }
    }
}


struct Demo_Previews: PreviewProvider {
    static var previews: some View {
        Demo()
    }
}
