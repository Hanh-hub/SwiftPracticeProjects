//
//  AddEditItemView.swift
//  LuluLemon
//
//  Created by Hanh Vo on 5/11/23.
//

import SwiftUI



struct AddEditItemView: View {
    @ObservedObject var viewModel: ItemViewModel
    
    @Environment(\.dismiss) var dismiss
    
    var item: Item?
    @State var itemName: String = ""
   
    var body: some View {
        
        VStack{
            TextField("Enter item name", text: $itemName)
               .textFieldStyle(RoundedBorderTextFieldStyle())
               .padding()
            
            Button(action: {
                if let item = item {
                    viewModel.updateItem(item: item, newName: itemName)
                } else {
                    viewModel.addItem(name: itemName)
                }
                viewModel.saveChanges()
                dismiss()
                
            }){
                Text(item == nil ? "Add Item" : "Save Changes")
                    .padding()
                    .frame(width: 150, height: 60)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .padding(.horizontal,25)
                
            }
            .padding()
            Spacer()
        }.padding()
        .navigationTitle(item == nil ? "Add Item" : "Edit Item")

    }
}

struct AddEditItemView_Previews: PreviewProvider {
    static var previews: some View {
        AddEditItemView(viewModel: ItemViewModel(), itemName: "Apple")
    }
}
