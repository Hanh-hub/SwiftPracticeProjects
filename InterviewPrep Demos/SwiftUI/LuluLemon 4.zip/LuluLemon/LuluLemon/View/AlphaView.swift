//
//  AlphaView.swift
//  LuluLemon
//
//  Created by Hanh Vo on 5/11/23.
//

import SwiftUI

struct AlphaView: View {
    @ObservedObject var viewModel: ItemViewModel
    @State private var selectedItem: Item? = nil
    
    var sortedBy: ItemDataManager.ItemSort
    
    var body: some View {
        VStack {
            List {
                ForEach(viewModel.items, id: \.self) { item in
                    NavigationLink(
                        destination: AddEditItemView(viewModel: viewModel,
                                                     item: item,
                                                     itemName: item.name ?? "unknown")
                    ){
                            Text(item.name ?? "unknown")
                    }
                }
                .onDelete(perform: delete)
            }
            .onAppear{
                viewModel.fetchItems(sortedBy: sortedBy)
            }
        }
    }
    
    private func delete(at offsets: IndexSet) {
        offsets.map { viewModel.items[$0] }.forEach(viewModel.deleteItem)
    }
}


struct AlphaView_Previews: PreviewProvider {
    static var previews: some View {
        AlphaView(viewModel: ItemViewModel(), sortedBy: .alphabetical)
    }
}
