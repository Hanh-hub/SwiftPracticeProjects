//
//  TimeView.swift
//  LuluLemon
//
//  Created by Hanh Vo on 5/11/23.
//

import SwiftUI

struct TimeView: View {
    @ObservedObject var viewModel: ItemViewModel
    @State private var selectedItem: Item? = nil
    @State private var showAddEditView = false
    
    var body: some View {
        VStack {
            List(viewModel.items){item in
                Text(item.name ?? "unknown")
                    .contentShape(Rectangle())
                    .onTapGesture {
                            selectedItem = item
                            showAddEditView = true
                        }
            }
            .onAppear{
                viewModel.fetchItems(sortedBy: .time)
            }
            .sheet(item: $selectedItem) { item in
                AddEditItemView(viewModel: viewModel, itemName: item.name!)
            }
        }
    }
}

struct TimeView_Previews: PreviewProvider {
    static var previews: some View {
        TimeView(viewModel: ItemViewModel())
    }
}
