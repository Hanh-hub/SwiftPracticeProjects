//
//  Model.swift
//  InstagramClone
//
//  Created by Hanh Vo on 5/24/23.
//

import Foundation
import SwiftUI

struct Profile: Identifiable {
    let id = UUID()
    let username: String
    let image: Image
    let hasStory: Bool = true
}

struct Message: Identifiable {
    let id: UUID
    let text: String
    let isFromCurrentUser: Bool
    let time: String
    let isDelivered: Bool
}


struct Post: Identifiable {
    let id = UUID()
    let username: String
    let text: String
    let image: Image
}
