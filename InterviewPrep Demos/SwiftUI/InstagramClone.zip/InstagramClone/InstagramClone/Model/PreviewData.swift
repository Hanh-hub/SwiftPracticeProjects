//
//  PreviewData.swift
//  InstagramClone
//
//  Created by Hanh Vo on 5/24/23.
//

import Foundation
import SwiftUI
let profiles: [Profile] = [
    Profile(username: "your story", image: Image("default-profile")),
    Profile(username: "banana1", image: Image("default-profile")),
    Profile(username: "johnNg123", image: Image("default-profile")),
    Profile(username: "Mariana_788", image: Image("default-profile")),
    Profile(username: "python_club", image: Image("default-profile")),
    Profile(username: "doctor_mike233", image: Image("default-profile")),
    Profile(username: "omg_tx222", image: Image("default-profile")),
]

let posts: [Post] = [
    Post(username: "bana", text: "hello", image: Image("default-profile")),
    Post(username: "apple123", text: "I love the feeling of the sand between my toes and the sun on my skin. There's nothing quite like spending a day at the beach to relax and clear your mind. #beach #summer #vacation #relaxation #sand #sun #ocean #travel #explore #wanderlust #instagood #photooftheday #igtravel #igdaily #beautiful #nature #wandering #exploremore #travelgram #instatravel #travelblogger #traveladdict #trip #instapic #instatraveling #travelphotography", image: Image("default-profile")),
    Post(username: "bana", text: "I love the feeling of the sand between my toes and the sun on my skin. There's nothing quite like spending a day at the beach to relax and clear your mind. #beach #summer #vacation #relaxation #sand #sun #ocean #travel #explore #wanderlust #instagood #photooftheday #igtravel #igdaily #beautiful #nature #wandering #exploremore #travelgram #instatravel #travelblogger #traveladdict #trip #instapic #instatraveling #travelphotography", image: Image("default-profile")),
    Post(username: "bana", text: "hello", image: Image("default-profile")),
    Post(username: "bana", text: "hello", image: Image("default-profile")),
    Post(username: "bana", text: "hello", image: Image("default-profile"))
]


