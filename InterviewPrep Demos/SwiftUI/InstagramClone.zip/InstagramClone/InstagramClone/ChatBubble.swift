//
//  ChatBubble.swift
//  InstagramClone
//
//  Created by Hanh Vo on 5/23/23.
//

import SwiftUI

struct ChatBubble: View {
    var message: Message
    
    var body: some View {
        HStack {
            if message.isFromCurrentUser {
                Spacer()
                Text(message.text)
                    .padding()
                    .background(Color.blue)
                    .clipShape(ChatBubbleShape(isFromCurrentUser: true))
                VStack(alignment: .trailing) {
                    Text(message.time)
                        .font(.footnote)
                    if message.isDelivered {
                        Image(systemName: "checkmark.seal.fill")
                            .font(.footnote)
                    }
                }
                .padding(.trailing, 10)
            } else {
                VStack(alignment: .leading) {
                    Text(message.time)
                        .font(.footnote)
                    if message.isDelivered {
                        Image(systemName: "checkmark.seal.fill")
                            .font(.footnote)
                    }
                }
                .padding(.leading, 10)
                Text(message.text)
                    .padding()
                    .background(Color.gray)
                    .clipShape(ChatBubbleShape(isFromCurrentUser: false))
                Spacer()
            }
        }
    }
}


struct ChatBubble_Previews: PreviewProvider {
    static var previews: some View {
        ChatBubble(message: Message(id: UUID(), text: "Hello!", isFromCurrentUser: true, time: "10:00 AM", isDelivered: true))
    }
}
