//
//  StoryListView.swift
//  InstagramClone
//
//  Created by Hanh Vo on 5/24/23.
//

import SwiftUI

struct StoryListView: View {
    var currentUser: Profile = Profile(username: "your Story", image: Image("default-profile"))
    var body: some View {
        HStack{
            VStack{
                currentUser.image
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 200, height: 200)
                    .cornerRadius(100)
                    
                Text(currentUser.username)
            }
 
        }
    }
}

struct StoryListView_Previews: PreviewProvider {
    static var previews: some View {
        StoryListView()
    }
}
