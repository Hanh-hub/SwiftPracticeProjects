//
//  AddNewPost.swift
//  InstagramClone
//
//  Created by Hanh Vo on 5/25/23.
//

import SwiftUI

struct AddNewPost: View {
    @State var showImagePicker = false
    @State var selectedImage: Image?
    @State var caption: String
    @State var viewModel: ViewModel
    @State var didFinishPicking = false
    var body: some View {
        VStack(alignment: .leading){
            
            HStack{
                if let image = selectedImage {
                    image.resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(height:100)
                }
                MultilineTextView("Write a caption",text: $caption)
                    .frame(height: 120)
            }
            
            HStack {
                Button(action:
                        {
                    showImagePicker = true
                }
                ){
                    Image(systemName: "photo")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(height: 30)
                }
                Spacer()
                if didFinishPicking {
                    Button("Share"){
                        viewModel.addPost(post: Post(username: "banana", text: caption, image: selectedImage!))
                        selectedImage = nil
                        caption = ""
                    }
                }
                
            }
           
 
        }
        .padding()
        .border(Color.black, width: 1)
        .padding()
        .sheet(isPresented: $showImagePicker){
            ImagePicker(image: $selectedImage, didFinishPicking: {didFinishPicking.toggle()})
        }
    }
}

struct AddNewPost_Previews: PreviewProvider {
    static var previews: some View {
        AddNewPost(selectedImage: Image("default-profile"), caption: sampleText, viewModel: ViewModel())
    }
}
