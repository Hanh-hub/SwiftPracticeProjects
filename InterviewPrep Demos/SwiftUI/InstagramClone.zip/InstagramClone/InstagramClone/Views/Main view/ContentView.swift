//
//  ContentView.swift
//  InstagramClone
//
//  Created by Hanh Vo on 5/23/23.
//

import SwiftUI

struct ContentView: View {
    @StateObject var viewModel: ViewModel = ViewModel()
    @State private var showingPopup = false
    var body: some View {
        TabView {
            
            NavigationView{
                VStack{
                    ScrollView{
                        NavBarView()
                        VStack{
                            
                            AddNewPost(caption: "Write a caption", viewModel: viewModel)
                                
                            
                               
                            ForEach(viewModel.allPosts.reversed()){post in
                            PostView(post: post)
                                    .padding(.bottom)
                            }
                        }
                    }
                }
            }
            .tabItem{
                Image(systemName: "house.fill")
            }
            //-------------------
            NavigationView{
                Text("search")
            }
            .tabItem{
                Image(systemName: "magnifyingglass")
            }
            //-------------------
            NavigationView{
                CreateNewPost(viewModel: viewModel)
            }
            .tabItem{
                Image(systemName: "plus.app")
            }
            //-------------------
            NavigationView{
                Text("reel")
            }
            .tabItem{
                Image(systemName: "video.fill")
            }
           
            //------------------
            NavigationView{
                Text("profile")
            }
            .tabItem{
                Image(systemName: "person.circle")
            }
        }
        .padding(.horizontal)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
