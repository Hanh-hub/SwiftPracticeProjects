//
//  PopUpMenu.swift
//  InstagramClone
//
//  Created by Hanh Vo on 5/24/23.
//

import SwiftUI

struct PopupView: View {
    var body: some View {
        VStack {
            Button(action: {
                print("Option 1 selected")
            }) {
                HStack {
                    Text("Following")
                    Image(systemName: "person.2")

                }
                
            }
            Divider()
            Button(action: {
                print("Option 2 selected")
            }) {
                HStack{
                    Text("Favorites")
                    Image(systemName: "star")
                }
                
            }
        }
        .frame(width: 150)
        .padding()
        .background(Color.white)
        .cornerRadius(10)
        .shadow(radius: 10)
    }
}


struct PopUpMenu_Previews: PreviewProvider {
    static var previews: some View {
        PopupView()
    }
}
