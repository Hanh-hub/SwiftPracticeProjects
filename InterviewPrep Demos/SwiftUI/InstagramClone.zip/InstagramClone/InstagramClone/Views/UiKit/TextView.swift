//
//  TextView.swift
//  InstagramClone
//
//  Created by Hanh Vo on 5/25/23.
//

import Foundation
import SwiftUI



struct MultilineTextView: UIViewRepresentable {
    private var placeholder: String
    @Binding private var text: String

    init(_ placeholder: String = "", text: Binding<String>) {
        self.placeholder = placeholder
        self._text = text
    }

    func makeUIView(context: Context) -> UITextView {
        let textView = UITextView()
        textView.delegate = context.coordinator
        textView.font = UIFont.preferredFont(forTextStyle: .body)
        textView.autocapitalizationType = .sentences
        textView.isSelectable = true
        textView.isUserInteractionEnabled = true
        textView.text = text
        textView.textColor = .label
    
        return textView
    }

    func updateUIView(_ uiView: UITextView, context: Context) {
        uiView.text = text
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator : NSObject, UITextViewDelegate {
        var parent: MultilineTextView

        init(_ textView: MultilineTextView) {
            self.parent = textView
        }

        func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
            if let swiftRange = Range(range, in: textView.text),
               let text = textView.text?.replacingCharacters(in: swiftRange, with: text) {
                parent.text = text
            }
            
            // calculate the number of lines
            let numLines = textView.contentSize.height / textView.font!.lineHeight
            if numLines <= 5 {
                return true
            } else {
                return false
            }
        }
    }

}
