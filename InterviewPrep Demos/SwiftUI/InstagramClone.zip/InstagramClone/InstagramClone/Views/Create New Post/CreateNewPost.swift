//
//  CreateNewPost.swift
//  InstagramClone
//
//  Created by Hanh Vo on 5/24/23.
//

import SwiftUI

struct CreateNewPost: View {
    @State var viewModel: ViewModel
    @State var selectedImage: Image!
    @State var isShowingNextView = false
    var body: some View {
        VStack{

            Text("Create new post")
            if let image = selectedImage {
                image
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: 200)
            } else {
                Image(systemName: "person")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: 200)
            }
 
            ImagePicker(image: $selectedImage, didFinishPicking: {
                isShowingNextView.toggle()
            })
            
            if isShowingNextView{
                NavigationLink(
                    destination: WriteACaption(viewModel: viewModel, selectedImage: selectedImage, caption: "testing")
                ){
                    Text("Share")
                }
            }
            
            
            Spacer()

        }
        
    }
}

struct CreateNewPost_Previews: PreviewProvider {
    static var previews: some View {
        CreateNewPost(viewModel: ViewModel(), selectedImage: Image("default-profile"))
    }
}
