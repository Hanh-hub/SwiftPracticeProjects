//
//  PostView.swift
//  InstagramClone
//
//  Created by Hanh Vo on 5/24/23.
//

import SwiftUI

struct PostView: View {
    var post: Post?
    var body: some View {
        VStack{
            post?.image
                .resizable()
                .aspectRatio(contentMode: .fit)
        
            Text(post?.text ?? "emtpy")
                
            HStack{
                Image(systemName: "suit.heart.fill")
                Image(systemName: "message")
                Image(systemName: "paperplane")
                Spacer()
            }
            
            
        }
    }
}

struct PostView_Previews: PreviewProvider {
    static var previews: some View {
        PostView(post: posts[0])
    }
}
