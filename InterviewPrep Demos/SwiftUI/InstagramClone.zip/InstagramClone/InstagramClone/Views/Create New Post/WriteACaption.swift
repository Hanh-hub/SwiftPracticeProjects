//
//  WriteACaption.swift
//  InstagramClone
//
//  Created by Hanh Vo on 5/25/23.
//

import SwiftUI

struct WriteACaption: View {
    var options = ["Tag People",  "Add Location", "Add Music", "Avdanced Setting"]
    @State var viewModel: ViewModel
    var selectedImage: Image
    @State var caption: String
    
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    
    var body: some View {
            VStack(alignment: .leading){
                HStack{
                    selectedImage
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(height: 130)
                    
                    MultilineTextView("Write a caption", text: $caption)
                        .frame(height: 150)
                        .padding()
                    
                }
                Divider()
                List(options, id: \.self){ option in
                    NavigationLink(destination: Text(option)){
                        Text(option)
                    }
                }
                
                Spacer()
            }
        .navigationTitle(Text("New post"))
        .toolbar{
            ToolbarItem(placement: .navigationBarTrailing){
                Button("Share", action: {
                    viewModel.addPost(post: Post(username: "banana", text: caption, image: selectedImage))
                   // presentationMode.wrappedValue.dismiss()
                    
                    print("Added")
                })
            }
        }
        //func postToTimeline()
    }
}

var sampleText: String = "Here, we're using a ZStack to layer our main content and the pop-up. The showingPopup state variable determines whether the pop-up is visible. When the  text is tapped, showingPopup is set to true, which triggers the pop-up to appear. When the pop-up is tapped, showingPopup is set to false, which makes the pop-up disappear. Note: This is a simple implementation and may not cover all your needs, but hopefully it gives you a good starting point. You might want to add more customization, like animations or positioning the pop-up relative to the tapped text."
struct WriteACaption_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView{
            WriteACaption(viewModel: ViewModel(), selectedImage: Image("default-profile"), caption:sampleText)
        }
       
    }
}
