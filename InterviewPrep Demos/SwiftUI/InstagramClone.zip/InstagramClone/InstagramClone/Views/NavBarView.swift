//
//  NavBarView.swift
//  InstagramClone
//
//  Created by Hanh Vo on 5/24/23.
//

import SwiftUI

struct NavBarView: View {
    @State var showingPopup = false
    var body: some View {
       
            HStack{
                Text("Instagram ")
                    .font(.custom("Grandista", size: 30))
                    .foregroundColor(.black)
                    .onTapGesture {
                        showingPopup.toggle()
                    }
                Spacer()
         
                NavigationLink(destination: Text("favorate")){
                    Image(systemName: "heart")
                }
               
                NavigationLink(destination: Text("messenger")){
                    Image(systemName: "ellipsis.message.fill")
                }
            }
            
            HStack{
                if showingPopup {
                   PopupView()
                       .onTapGesture {
                           showingPopup = false
                       }
                       .transition(.scale)
                }
                Spacer()
            }
            Spacer()
           
        
            
        
    }
}

struct NavBarView_Previews: PreviewProvider {
    static var previews: some View {
        NavBarView()
    }
}
