//
//  ChatBubbleShape.swift
//  InstagramClone
//
//  Created by Hanh Vo on 5/23/23.
//

import Foundation
import SwiftUI

struct ChatBubbleShape: Shape {
    var isFromCurrentUser: Bool
    
    func path(in rect: CGRect) -> Path {
        var path = Path()
        
        if isFromCurrentUser {
            path.addArc(center: CGPoint(x: rect.maxX, y: rect.minY), radius: 10, startAngle: .degrees(-90), endAngle: .degrees(0), clockwise: false)
            path.addArc(center: CGPoint(x: rect.maxX, y: rect.maxY), radius: 10, startAngle: .degrees(0), endAngle: .degrees(90), clockwise: false)
            path.addArc(center: CGPoint(x: rect.minX, y: rect.maxY), radius: 10, startAngle: .degrees(90), endAngle: .degrees(180), clockwise: false)
            path.addLine(to: CGPoint(x: rect.minX, y: rect.minY))
        } else {
            path.addArc(center: CGPoint(x: rect.minX, y: rect.minY), radius: 10, startAngle: .degrees(-180), endAngle: .degrees(-90), clockwise: false)
            path.addArc(center: CGPoint(x: rect.maxX, y: rect.minY), radius: 10, startAngle: .degrees(-90), endAngle: .degrees(0), clockwise: false)
            path.addArc(center: CGPoint(x: rect.maxX, y: rect.maxY), radius: 10, startAngle: .degrees(0), endAngle: .degrees(90), clockwise: false)
            path.addLine(to: CGPoint(x: rect.minX, y: rect.maxY))
        }
        
        return path
    }
}
