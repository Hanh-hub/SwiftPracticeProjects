//
//  ViewModel.swift
//  InstagramClone
//
//  Created by Hanh Vo on 5/24/23.
//

import Foundation


class ViewModel: ObservableObject {
    
    @Published var allPosts: [Post] = posts
//    func getPosts(){
//        allPosts = posts
//    }
    
    func addPost(post: Post){
        allPosts.append(post)
    }
}
