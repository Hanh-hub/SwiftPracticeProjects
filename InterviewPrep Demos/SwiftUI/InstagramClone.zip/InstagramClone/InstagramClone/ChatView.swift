//
//  ChatView.swift
//  InstagramClone
//
//  Created by Hanh Vo on 5/23/23.
//

import SwiftUI

struct ChatView: View {
    let messages: [Message] = [
        Message(id: UUID(), text: "Hello!", isFromCurrentUser: true, time: "10:00 AM", isDelivered: true),
        Message(id: UUID(), text: "Hi, how are you?", isFromCurrentUser: false, time: "10:01 AM", isDelivered: true),
        Message(id: UUID(), text: "I'm good, thanks. And you?", isFromCurrentUser: true, time: "10:02 AM", isDelivered: true),
        Message(id: UUID(), text: "I'm great! Do you have plans for the weekend?", isFromCurrentUser: false, time: "10:03 AM", isDelivered: true)
    ]
    
    var body: some View {
        VStack {
            ScrollView {
                VStack {
                    ForEach(messages) { message in
                        ChatBubble(message: message)
                            .padding(5)
                            .cornerRadius(50)
                    }
                }
            }
            Spacer()
        }
    }
}

struct ChatView_Previews: PreviewProvider {
    static var previews: some View {
        ChatView()
    }
}
