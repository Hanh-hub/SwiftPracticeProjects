//
//  InstagramCloneApp.swift
//  InstagramClone
//
//  Created by Hanh Vo on 5/23/23.
//

import SwiftUI

@main
struct InstagramCloneApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
