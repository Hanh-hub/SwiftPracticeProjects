//
//  Model.swift
//  LuluLemon
//
//  Created by Hanh Vo on 5/11/23.
//

import Foundation


struct ItemModel {
    var name: String
    var timeStamp: Date
}
