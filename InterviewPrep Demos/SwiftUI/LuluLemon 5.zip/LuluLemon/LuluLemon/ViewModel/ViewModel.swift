//
//  ViewModel.swift
//  LuluLemon
//
//  Created by Hanh Vo on 5/11/23.
//

import Foundation

class ItemViewModel: ObservableObject {
    @Published var items = [Item]()
  //  private let dataManager = ItemDataManager.shared

//    init(dataManager: ItemDataManager) {
//        self.dataManager = dataManager
//    }
    private let dataManager: ItemDataManagerProtocol
    
    init(dataManager: ItemDataManagerProtocol = ItemDataManager.shared) {
            self.dataManager = dataManager
        }
    
    func addItem(name: String) {
        dataManager.addItem(name: name)
        fetchItems(sortedBy: .time)
    }

    func fetchItems(sortedBy: ItemDataManager.ItemSort) {
        items = dataManager.fetchItems(sortedBy: sortedBy)
       
    }
    
    func fetchItems2(sortedBy: ItemDataManager.ItemSort) {
        dataManager.fetchItems2(sortedBy: sortedBy){ [weak self] items in
            DispatchQueue.main.async {
                self?.items = items
            }
        }
    }

    func saveChanges(){
        dataManager.saveChange()
    }
    
    func updateItem(item: Item, newName: String) {
           dataManager.updateItem(item: item, newName: newName)
       }
    func deleteItem(item: Item) {
        dataManager.deleteItem(item: item)
    }
}
