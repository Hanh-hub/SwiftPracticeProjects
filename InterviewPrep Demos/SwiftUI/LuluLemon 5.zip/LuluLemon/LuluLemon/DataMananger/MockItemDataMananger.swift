//
//  MockItemDataMananger.swift
//  LuluLemonTests
//
//  Created by Hanh Vo on 5/16/23.
//

import Foundation
import CoreData

class MockItemDataManager: ItemDataManagerProtocol {
    func fetchItems2(sortedBy: ItemDataManager.ItemSort, completion: @escaping ([Item]) -> ()) {
        // Simulate a delay for fetching items
        DispatchQueue.global().asyncAfter(deadline: .now() + 0.1) {
            let items = self.items
            switch sortedBy {
            case .alphabetical:
                completion(items.sorted { $0.name ?? "" < $1.name ?? "" })
            case .time:
                completion(items.sorted { $0.timestamp ?? Date() < $1.timestamp ?? Date() })
            }
        }
    }

    
    var items: [Item] = []

    func addItem(name: String) {
        let newItem = Item(context: NSManagedObjectContext(concurrencyType: .mainQueueConcurrencyType)) // Create a mock item
        newItem.name = name
        items.append(newItem)
    }

    func fetchItems(sortedBy: ItemDataManager.ItemSort) -> [Item] {
        switch sortedBy {
        case .alphabetical:
            return items.sorted(by: { $0.name! < $1.name! })
        case .time:
            return items.sorted(by: { $0.timestamp! < $1.timestamp! })
        }
    }

    func saveChange() {
        // In a mock environment, you don't actually save changes.
        // This function could be used to test if it gets called correctly.
    }

    func updateItem(item: Item, newName: String) {
        if let index = items.firstIndex(of: item) {
            items[index].name = newName
        }
    }

    func deleteItem(item: Item) {
        if let index = items.firstIndex(of: item) {
            items.remove(at: index)
        }
    }
}
