//
//  ItemDataManger.swift
//  LuluLemon
//
//  Created by Hanh Vo on 5/11/23.
//

import Foundation
import CoreData

protocol ItemDataManagerProtocol {
    func addItem(name: String)
    func fetchItems(sortedBy: ItemDataManager.ItemSort) -> [Item]
    func saveChange()
    func updateItem(item: Item, newName: String)
    func deleteItem(item: Item)
    func fetchItems2(sortedBy: ItemDataManager.ItemSort, completion: @escaping ([Item]) -> Void)
}

extension ItemDataManager: ItemDataManagerProtocol { }



class ItemDataManager{
   // var viewContext: NSManagedObjectContext
    var container = NSPersistentContainer(name: "GarmentTypeModel")
    
    init(inMemory: Bool = false) {
        if inMemory {
                   container.persistentStoreDescriptions.first?.url = URL(fileURLWithPath: "/dev/null")
        }
        container.loadPersistentStores {description, error in
            if let error = error as? NSError {
                fatalError("error loading data \(error) \(error.userInfo)")
            }
            
        }
       
            // self.viewContext = container.viewContext
       
    }
    var viewContext: NSManagedObjectContext {
        return container.viewContext
    }
    
    
  
    static let shared = ItemDataManager()
    
    private func backgroundContext() -> NSManagedObjectContext {
        return container.newBackgroundContext()
    }
    
    func addItem(name: String) {
        let backgroundContext = self.backgroundContext()
        backgroundContext.perform {
            let newItem = Item(context: backgroundContext)
            newItem.name = name
            newItem.timestamp = Date()

            do {
                try backgroundContext.save()
            } catch {
                print("Error adding item: \(error)")
            }
        }

       }
    
    
    func fetchItems(sortedBy: ItemSort) -> [Item] {
           let request: NSFetchRequest<Item> = Item.fetchRequest()
           switch sortedBy {
           case .alphabetical:
               request.sortDescriptors = [NSSortDescriptor(keyPath: \Item.name, ascending: true)]
           case .time:
               request.sortDescriptors = [NSSortDescriptor(keyPath: \Item.timestamp, ascending: true)]
           }

           do {
               let items = try viewContext.fetch(request)
               return items
           } catch {
               print("Error fetching items: \(error)")
               return []
           }
       }
    func fetchItems2(sortedBy: ItemSort, completion: @escaping ([Item]) -> Void) {
        let privateContext = NSManagedObjectContext(concurrencyType: .privateQueueConcurrencyType)
        privateContext.parent = viewContext

        privateContext.perform {
            let request: NSFetchRequest<Item> = Item.fetchRequest()
            switch sortedBy {
            case .alphabetical:
                request.sortDescriptors = [NSSortDescriptor(keyPath: \Item.name, ascending: true)]
            case .time:
                request.sortDescriptors = [NSSortDescriptor(keyPath: \Item.timestamp, ascending: true)]
            }

            do {
                let items = try privateContext.fetch(request)
                completion(items)
            } catch {
                print("Error fetching items: \(error)")
                completion([])
            }
        }
    }

    
    func saveChange(){
        do {
            try viewContext.save()
        } catch let error{
            print("error saving  \(error)")
        }
       
    }
    
    func updateItem(item: Item, newName: String) {
            item.name = newName
       
            do {
                try viewContext.save()
            } catch {
                print("Error updating item: \(error)")
            }
        }
    
    func deleteItem(item: Item) {
        let backgroundContext = container.newBackgroundContext()
        let itemID = item.objectID

        backgroundContext.perform {
            do {
                let itemToDelete = backgroundContext.object(with: itemID)
                backgroundContext.delete(itemToDelete)

                try backgroundContext.save()

                DispatchQueue.main.async {
                    self.viewContext.mergeChanges(fromContextDidSave: .init(name: .NSManagedObjectContextDidSave, object: backgroundContext))
                }
            } catch {
                print("Error deleting item: \(error)")
            }
        }
    }

//    func deleteItem(item: Item) {
//        viewContext.delete(item)
//
//        do {
//            try viewContext.save()
//        } catch {
//            print("Error deleting item: \(error)")
//        }
//    }
    
    enum ItemSort {
        case alphabetical
        case time
    }
}
