//
//  LuluLemonApp.swift
//  LuluLemon
//
//  Created by Hanh Vo on 5/11/23.
//

import SwiftUI

@main
struct LuluLemonApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
