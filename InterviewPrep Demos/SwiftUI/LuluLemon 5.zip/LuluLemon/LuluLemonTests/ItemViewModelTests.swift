//
//  ItemViewModelTests.swift
//  LuluLemonTests
//
//  Created by Hanh Vo on 5/16/23.
//

import XCTest
@testable import LuluLemon
import CoreData

final class ItemViewModelTests: XCTestCase {
    var sut: ItemViewModel!
    var mockDataManager: MockItemDataManager!

    override func setUp() {
        super.setUp()
        mockDataManager = MockItemDataManager()
        sut = ItemViewModel(dataManager: mockDataManager!)
    }

    override func tearDown() {
        sut = nil
        mockDataManager = nil
        super.tearDown()
    }

    func testFetchItems() {
        // Given
        let item1 = Item(context: NSManagedObjectContext(concurrencyType: .mainQueueConcurrencyType)) // Create a mock item
        item1.name = "Item 1"
        mockDataManager.items = [item1] // Set the items to return in the mock data manager

        // When
        sut.fetchItems(sortedBy: .alphabetical)

        // Then
        XCTAssertEqual(sut.items.count, 1, "Fetch should return all items.")
        XCTAssertEqual(sut.items[0].name, item1.name, "Items should match the mock data.")
    }

    // Other tests...
}

