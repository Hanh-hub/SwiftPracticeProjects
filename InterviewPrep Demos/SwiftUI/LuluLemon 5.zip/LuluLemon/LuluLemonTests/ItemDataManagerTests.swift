//
//  ItemDataManagerTests.swift
//  LuluLemonTests
//
//  Created by Hanh Vo on 5/16/23.
//

import XCTest
@testable import LuluLemon
final class ItemDataManagerTests: XCTestCase {
    var sut: ItemDataManager!
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        sut = ItemDataManager(inMemory: true)
        let exp = expectation(description: "Wait for store to load")
                sut.container.loadPersistentStores { _, _ in
                    exp.fulfill()
                }
                waitForExpectations(timeout: 1.0)
    }

    override func tearDownWithError() throws {
        
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        sut = nil
        super.tearDown()
    }
    
    func testAddItem() {
           // Given
           let itemName = "Test Item"

           // When
           sut.addItem(name: itemName)

           // Then
           let items = sut.fetchItems(sortedBy: .alphabetical)
           XCTAssertEqual(items.count, 1)
           XCTAssertEqual(items.first?.name, itemName)
       }

    func testFetchItems() {
            // Given
            let item1 = "Item 1"
            let item2 = "Item 2"
            sut.addItem(name: item1)
            sut.addItem(name: item2)

            // When
            let fetchedItems = sut.fetchItems(sortedBy: .alphabetical)

            // Then
            XCTAssertEqual(fetchedItems.count, 2, "Fetch should return all items.")
            XCTAssertEqual(fetchedItems[0].name, item1, "Items should be sorted alphabetically.")
            XCTAssertEqual(fetchedItems[1].name, item2, "Items should be sorted alphabetically.")
        }
    
    func testUpdateItem() {
           // Given
           let originalName = "Original"
           let updatedName = "Updated"
           sut.addItem(name: originalName)
           let itemToUpdate = sut.fetchItems(sortedBy: .alphabetical).first!

           // When
           sut.updateItem(item: itemToUpdate, newName: updatedName)

           // Then
           let updatedItems = sut.fetchItems(sortedBy: .alphabetical)
           XCTAssertEqual(updatedItems.first?.name, updatedName, "Item name should be updated.")
       }
    func testDeleteItem() {
           // Given
           let itemName = "Test Item"
           sut.addItem(name: itemName)
           let itemToDelete = sut.fetchItems(sortedBy: .alphabetical).first!

           // When
           sut.deleteItem(item: itemToDelete)

           // Then
           let remainingItems = sut.fetchItems(sortedBy: .alphabetical)
           XCTAssertTrue(remainingItems.isEmpty, "All items should be deleted.")
       }
    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        // Any test you write for XCTest can be annotated as throws and async.
        // Mark your test throws to produce an unexpected failure when your test encounters an uncaught error.
        // Mark your test async to allow awaiting for asynchronous code to complete. Check the results with assertions afterwards.
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
