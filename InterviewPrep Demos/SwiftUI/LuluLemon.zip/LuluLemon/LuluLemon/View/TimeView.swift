//
//  TimeView.swift
//  LuluLemon
//
//  Created by Hanh Vo on 5/11/23.
//

import SwiftUI

struct TimeView: View {
    @ObservedObject var viewModel: ItemViewModel

    var body: some View {
        VStack {
            List(viewModel.items){item in
                Text(item.name ?? "unknown")
            }
            .onAppear{
                viewModel.fetchItems(sortedBy: .time)
            }
        }
    }
}

struct TimeView_Previews: PreviewProvider {
    static var previews: some View {
        TimeView(viewModel: ItemViewModel())
    }
}
