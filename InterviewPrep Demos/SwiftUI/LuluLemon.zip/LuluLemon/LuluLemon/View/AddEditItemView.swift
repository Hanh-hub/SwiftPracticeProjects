//
//  AddEditItemView.swift
//  LuluLemon
//
//  Created by Hanh Vo on 5/11/23.
//

import SwiftUI

struct AddEditItemView: View {
    @ObservedObject var viewModel: ItemViewModel
    @State var itemName: String = ""
    @Environment(\.dismiss) var dismiss
    
    var item: Item? 
    
    var body: some View {
        
        VStack{
            TextField(item == nil ? "Enter name" : item!.name!, text: $itemName)
                .padding()
            
            Button(action: {
                if let item = item, let name = item.name {
                    itemName = name
                } else {
                    viewModel.addItem(name: itemName)
                }
                viewModel.saveChanges()
                dismiss()
                
            } ){
                Text(item == nil ? "Add Item" : "Save Changes")
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(20)
                    .padding(.horizontal,40)
                
            }
            .padding()
            Spacer()
        }.padding()
        .navigationTitle(item == nil ? "Add Item" : "Edit Item")
        
        
    }
}

struct AddEditItemView_Previews: PreviewProvider {
    static var previews: some View {
        AddEditItemView(viewModel: ItemViewModel())
    }
}
