//
//  AlphaView.swift
//  LuluLemon
//
//  Created by Hanh Vo on 5/11/23.
//

import SwiftUI

struct AlphaView: View {
    @ObservedObject var viewModel: ItemViewModel
    @State private var selectedItem: Item? = nil
    @State private var showAddEditView = false

    var body: some View {
        VStack {
            List(viewModel.items){item in
                Text(item.name ?? "unknown")
                    .contentShape(Rectangle())
                    .onTapGesture {
                            selectedItem = item
                            showAddEditView = true
                        }
            }
            .onAppear{
                viewModel.fetchItems(sortedBy: .alphabetical)
            }
            .sheet(item: $selectedItem) { item in
                AddEditItemView(viewModel: viewModel, item: item)
            }
        }
    }
}

struct AlphaView_Previews: PreviewProvider {
    static var previews: some View {
        AlphaView(viewModel: ItemViewModel())
    }
}
