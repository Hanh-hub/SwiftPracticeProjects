////
////  ListViewModel2.swift
////  MusicAppSwiftUI
////
////  Created by Hanh Vo on 4/3/23.
////
//
//import Foundation
//
//enum ListViewModelError: Error {
//    case networkError(Error)
//    case parsingError(Error)
//    
//    var message: String {
//        switch self {
//        case .networkError(let error):
//            return "An error occurred while fetching song data. Please try again later. (Error: \(error.localizedDescription))"
//        case .parsingError(let error):
//            return "An error occurred while parsing song data. Please try again later. (Error: \(error.localizedDescription))"
//        }
//        
//    }
//}
//
//class ListViewModel2 {
//    var songList: [Song] = []
//    
//    private func decode<T: Decodable>(from data: Data) -> Result<T, ListViewModelError> {
//        do {
//            let decodedData = try JSONDecoder().decode(T.self, from: data)
//            return .success(decodedData)
//        } catch let error {
//            return .failure(.parsingError(error))
//        }
//    }
//    
//    func getSongData(songOrArtist: String, onCompletion: @escaping () -> Void){
//        APIHandler.shared.fetchAPI(url: API.searchURL(for: songOrArtist)) { result in
//            switch result {
//            
//            }
//            
//        }
//        
//    }
//    //
//}
