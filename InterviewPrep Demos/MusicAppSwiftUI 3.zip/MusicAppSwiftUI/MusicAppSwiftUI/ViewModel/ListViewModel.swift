//
//  ListViewModel.swift
//  MusicAppSwiftUI
//
//  Created by Hanh Vo on 4/3/23.
//

import Foundation
import UIKit
import SwiftUI

//class ViewModel {
//    //var songResult: [Song]?
//    var songList: [Song] = []
//
//    private func decode<T: Codable>(from data: Data) throws -> T {
//        let decoder = JSONDecoder()
//        return try decoder.decode(T.self, from: data)
//    }
//  //  let imageCache = NSCache<NSURL, UIImage>()
//    let imageCache = NSCache<NSURL, UIImage>()
//
//    func getSongData(songOrArtist: String, onCompletion: @escaping ()-> Void){
//        print("get song data")
//        APIHandler.shared.fetchAPI(url: API.searchURL(for: songOrArtist)){result in
//
//            switch result {
//            case .success(let data):
//                do {
//                    let parsedData: SongResult = try self.decode(from: data)
//                    self.songList = parsedData.results
//                               // Handle the parsed data
//                    onCompletion()
//                } catch {
//                    print("Error decoding data: \(error)")
//
//                }
//            case .failure(let error):
//                print("error getting data \(error)")
//            }
//        }
//    }
//
//    func getNumOfRows() -> Int {
//        //return songResult?.count ?? 0
//        return songList.count
//    }
//}


enum ViewModelError: Error {
    case networkError(Error)
    case parsingError(Error)
    case invalidDataError
}

class ListViewModel: ObservableObject {
    @Published var songList: [Song] = []
    var error: String = ""
    @Published var imageCache = NSCache<NSURL, UIImage>()
    
    private func decode<T: Decodable>(from data: Data) -> Result<T, ViewModelError> {
        let decoder = JSONDecoder()
        do {
            let decodedData = try decoder.decode(T.self, from: data)
            return .success(decodedData)
        } catch let error {
            return .failure(.parsingError(error))
        }
    }
    
    func getSongData(for songOrArtist: String, onCompletion: @escaping () -> Void) {
        APIHandler.shared.fetchAPI(url: API.searchURL(for: songOrArtist)) { result in
            switch result {
            case .success(let data):
                let parsedDataResult: Result<SongResult, ViewModelError> = self.decode(from: data)
                switch parsedDataResult {
                case .success(let parsedData):
                    
                    DispatchQueue.main.async {
                        self.songList = parsedData.results
                        self.songList =  Array(self.songList.prefix(3))
                                   }
                    
                    onCompletion()
                case .failure(let error):
                    print("there is data but cannot decode data")
                    print(error)
                    self.error = error.localizedDescription
                }
            case .failure(let error):
                print("failed to request data")
                self.error = error.localizedDescription
            }
        }
    }
    
    func getNumOfRows() -> Int {
       // return songList.count
        return 3
    }
    func getImageFromCache(imageUrl: String?) -> UIImage{
        guard let urlString = imageUrl else {
            //print("no url string in image")
            return UIImage(named: "music-note")!
        }
        guard let url = NSURL(string: urlString), let image =  imageCache.object(forKey: url) else {
            //print("uh oh there is url strinb but no cached image found")
            return UIImage(named: "music-note")!
        }
        
        return image
    }
}
