//
//  PlayerViewModel.swift
//  MusicAppSwiftUI
//
//  Created by Hanh Vo on 4/4/23.
//


import Foundation
import AVFAudio
import AVFoundation
import UIKit

class PlayerViewModel: ObservableObject {
    @Published var song: Song
    
    
    private var player: AVPlayer?
    private var timeObserver: Any?
    private var lastSliderValue: Double = 0.0
    var cachedImage: UIImage!
    
    @Published var isPlaying: Bool = false
    @Published var currentTime: TimeInterval = 0
    @Published var duration: TimeInterval = 0
    
    
    
    init(song: Song, cachedImage: UIImage? = nil) {
        self.song = song
        self.cachedImage = cachedImage
//        guard let stringUrl =  song.previewURL,  let url = URL(string: stringUrl) else {
//            return
//        }
//        player = AVPlayer(url: url)
//        player?.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.01, preferredTimescale: 1000), queue: DispatchQueue.main) { [weak self] cmTime in
//            self?.currentTime = cmTime.seconds
//        }
//
//        timeObserver = player?.addBoundaryTimeObserver(forTimes: [NSValue(time: player?.currentItem?.duration ?? CMTime.zero)], queue: DispatchQueue.main) { [weak self] in
//                   self?.isPlaying = false
//               }
        
        
    //using: <#T##(CMTime) -> Void#>)
        print("init player view model for song \(self.song.trackID ?? 0000) \(song.trackName ?? "no name")")
    }
    
    

    func play(){
       // if there no player
        if player == nil {
            guard let previewURL = URL(string: song.previewURL!) else {
               // print("no valid preview url")
                return
            }
            let playerItem = AVPlayerItem(url: previewURL)
            self.player = AVPlayer(playerItem: playerItem)
            //player?.addObserver(self as? NSObject ?? <#default value#>, forKeyPath: "timeControlStatus", options: [.old, .new], context: nil)

        }
        
        player?.play()
        isPlaying = true
    
    }
        
  
    func pause() {
            player?.pause()
            isPlaying = false
        }
    
   
   
//    func getDuration() async -> Double {
//        guard let urlString = song.previewURL, let url = URL(string: urlString) else {
//            return 0.0
//        }
//
//        let asset = AVURLAsset(url: url)
//        do {
//            let duration = try await asset.load(.duration)
//            return duration.seconds
//        } catch {
//            print("Failed to load duration: \(error.localizedDescription)")
//            return 0.0
//        }
//    }
    
    func getDuration() async -> CMTime {
        guard let urlString = song.previewURL, let url = URL(string: urlString) else {
            return .zero
        }

        let asset = AVURLAsset(url: url)
        do {
            let duration = try await asset.load(.duration)
            return duration
        } catch {
            print("Failed to load duration: \(error.localizedDescription)")
            return .zero
        }
    }
    
    func addPeriodicTimeObserver(updateHandler: @escaping (CMTime) -> Void) {
          timeObserver = player?.addPeriodicTimeObserver(forInterval: CMTime(seconds: 1, preferredTimescale: 1000), queue: DispatchQueue.main) { [weak self] time in
              updateHandler(time)

              if time.seconds >= self?.player?.currentItem?.duration.seconds ?? 0 {
                  self?.isPlaying = false
              }
          }
      }


    
    private var durationObserver: NSKeyValueObservation?

    func getDuration(completion: @escaping (CMTime?) -> Void) {
        durationObserver = player?.currentItem?.observe(\.duration, options: [.new, .initial]) { [weak self] (playerItem, _) in
            if playerItem.status == .readyToPlay {
                completion(playerItem.duration)
                self?.durationObserver = nil
            }
        }
    }

    func getCurrentTime() -> CMTime? {
            return player?.currentTime()
        }
    
    func seek(to time: CMTime) {
            player?.seek(to: time)
        player?.play()
        isPlaying = true
        }
    
    deinit {
        if let observer = timeObserver {
            player?.removeTimeObserver(observer)
            timeObserver = nil
        }
        print("DE-INIT player view model for song \(self.song.trackID ?? 0000) \(song.trackName ?? "no name")")
    }
}

