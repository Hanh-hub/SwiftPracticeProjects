//
//  ImageMessageTableViewCell.swift
//  FireBaseDemo
//
//  Created by Hanh Vo on 4/24/23.
//

import UIKit

class ImageMessageTableViewCell: UITableViewCell {
    //@IBOutlet weak var messageContainer: UIView!
    @IBOutlet weak var messageImageView: UIImageView!
    // @IBOutlet weak var senderImageView: UIImageView!
    private var imageViewLeadingConstraint: NSLayoutConstraint?
    private var imageViewTrailingConstraint: NSLayoutConstraint?

    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        //messageImageView.image = UIImage(named: "defaultImage")
        setUpViews()
       // setUpImageViewConstraints()
        //setUpContainerConstraints()
        // setupMessageImageViewConstraints()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    private func setUpViews() {
        contentView.addSubview(messageImageView)
        messageImageView.translatesAutoresizingMaskIntoConstraints = false
    }
    private func setUpImageViewConstraints(isSent: Bool) {
        messageImageView.contentMode = .scaleAspectFit
        if isSent {
            imageViewLeadingConstraint = messageImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 80)
            imageViewTrailingConstraint = messageImageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -8)
        } else {
            imageViewLeadingConstraint = messageImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 8)
            imageViewTrailingConstraint = messageImageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -80)
        }
       

        NSLayoutConstraint.activate([
            messageImageView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 8),
            messageImageView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -8),
            //messageImageView.widthAnchor.constraint(lessThanOrEqualToConstant: contentView.frame.width * 0.75),
            messageImageView.heightAnchor.constraint(lessThanOrEqualToConstant: 300)
        ])
    }
    
    func configureImage(with message: Message, currentUserId: String) {
        let isSent = message.senderId == currentUserId

        if isSent {
//            imageViewLeadingConstraint?.isActive = true
//            imageViewTrailingConstraint?.isActive = true
            setUpImageViewConstraints(isSent: true)
        } else {
//            imageViewLeadingConstraint?.isActive = true
//            imageViewTrailingConstraint?.isActive = true
            setUpImageViewConstraints(isSent: false)
        }

        NSLayoutConstraint.activate([
            imageViewLeadingConstraint!,
            imageViewTrailingConstraint!
        ])

        guard let imageUrl = message.imageUrl else {
            print("invalid image url")
            return
        }

        messageImageView.setImageFromUrl(imageUrl)
    }


}


