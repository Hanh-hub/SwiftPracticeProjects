//
//  Constants.swift
//  SDWebImageDemo
//
//  Created by Hanh Vo on 4/10/23.
//

import Foundation

let baseUrl = "https://dummyjson.com/products"
