//
//  ProductTableViewCell.swift
//  SDWebImageDemo
//
//  Created by Hanh Vo on 4/10/23.
//

import UIKit

class ProductTableViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var ratingLabel: UILabel!
    @IBOutlet weak var productImage: UIImageView!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func configure(with product: Product) {
        titleLabel.text = product.title
        priceLabel.text = product.price?.description
        ratingLabel.text = product.rating?.description
    }

}
