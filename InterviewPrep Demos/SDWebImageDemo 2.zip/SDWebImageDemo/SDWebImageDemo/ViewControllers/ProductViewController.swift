//
//  ProductViewController.swift
//  SDWebImageDemo
//
//  Created by Hanh Vo on 4/10/23.
//


import UIKit
import SDWebImage
import RxSwift
import RxCocoa
import Alamofire



class ProductViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!

    let viewModel = ViewModel()
    let disposeBag = DisposeBag()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupTableView()
        bindViewModel()
    }

//    private func setupTableView() {
//        tableView.register(UINib(nibName: "ProductTableViewCell", bundle: nil), forCellReuseIdentifier: "ProductTableViewCell")
//    }
    private func setupTableView() {
        tableView.register(ProductTableViewCell.self, forCellReuseIdentifier: "ProductTableViewCell")
    }


    private func bindViewModel() {
        viewModel.products
            .bind(to: tableView.rx.items(cellIdentifier: "ProductTableViewCell", cellType: ProductTableViewCell.self)) { (_, product, cell) in
                cell.configure(with: product)
            }
            .disposed(by: disposeBag)

        viewModel.getData()
            .subscribe(onNext: { _ in
                // Handle successful data fetch
            }, onError: { error in
                // Handle error during data fetch
                print("Error: \(error.localizedDescription)")
            })
            .disposed(by: disposeBag)
    }
}
