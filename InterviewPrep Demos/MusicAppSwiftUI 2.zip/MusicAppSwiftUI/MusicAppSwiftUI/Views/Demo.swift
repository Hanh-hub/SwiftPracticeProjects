//
//  Demo.swift
//  MusicAppSwiftUI
//
//  Created by Hanh Vo on 4/5/23.
//

import SwiftUI
import SwiftUI

class CounterViewModel: ObservableObject {
    var count = 0
    
    func increment() {
        count += 1
    }
}

struct Demo: View {
    @ObservedObject var viewModel = CounterViewModel()
    
    var body: some View {
        VStack {
            Text("Count: \(viewModel.count)")
            
            Button("Increment") {
                viewModel.increment()
            }
        }
    }
}




struct Demo_Previews: PreviewProvider {
    static var previews: some View {
        Demo()
    }
}
