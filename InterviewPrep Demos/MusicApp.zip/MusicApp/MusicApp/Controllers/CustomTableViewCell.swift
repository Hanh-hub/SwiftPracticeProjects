//
//  CustomTableViewCell.swift
//  MusicApp
//
//  Created by Hanh Vo on 3/29/23.
//

import Foundation
import UIKit

class CustomTableViewCell: UITableViewCell {
    
    @IBOutlet weak var songThumbnail: UIImageView!
    @IBOutlet weak var artistNameLabel: UILabel!
    @IBOutlet weak var songTitleLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    func setCellData(song: Song, cache: NSCache<NSURL, UIImage>){
        artistNameLabel.text = song.artistName
        songTitleLabel.text = song.trackName
        songThumbnail.setImage(from: URL(string: song.artworkUrl100)!, cache: cache)
    }
}



